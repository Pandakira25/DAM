Proceso Tarea1_Secuenciales_Ej2
	
	//@Alumno:zoe
	//@Revisor:David Martinez
	
	//Dadas dos variables num�ricas A y B, que el usuario debe teclear, se pide realizar un algoritmo que intercambie los valores de ambas variables y muestre cuanto valen al final las dos variables.
	
	//An�lisis:
	// Tengo que leer A y B y luego mediante una variable de cambio, c, intercambiar sus valores primero asignando a c el valor de A o B luego le asgino a la que haya elegido el valor de la contraria, y por �ltimo le asigno a a la contraria el 
	//valro de la variable de cambio.
	//Datos de entrada: A y B
	//Variables A , B , c
	
	//Dise�o
	//1. Leer A y B
	//2. Asignar c = a
	//3. Asignar  A = B
	//4. Asignar B = C
	//2. Mostrar ahora A vale "B" y ahora B vale "A" 
	
	Definir A , B , C Como Real;
	
	Escribir "Ingrese el valor de A";
	Leer A;
	Escribir "Ingrese el valor de B";
	Leer B;
	
	C := A;
	A := B;
	B := C;
	
	Escribir "El nuevo valor de A es: ", A , ". El nuevo valor de B es: " , B;
	
FinProceso

//a = a XOR b
//b = a XOR b
//a = a XOR b

// No hay ningun fallo aunque como curiosidad asi es como haces un swap usando XOR lo qque nos ahorra la variable intermedia