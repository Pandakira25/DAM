Proceso Tarea1_Secuenciales_Ej1
	
	//@alumno:zoe
	//@Revisor:Juan Ros Fern�ndez
	//Un alumno desea saber cual ser� su calificaci�n final en UD.
	//la calificaci�n se compone de los siguientes  porcentajes:20% Primer Test, 20% Segundo Test, 60% Pr�ctica
    
	//An�lisis:
	//Tengo que leer las tres calificaciones y calcular la suma total de estas 
	//Calcular cuanto valdr�a la calificaci�n m�xima
	//Datos de entrada: Primer_Test, Segundo_Test, Pr�ctica
	//Informacion de salida= Calificacion_Final.
	//Variables: Pt, St, Pr, C_f(Calificaci�n final), C_M(Calificaci�n M�xima), S_c(Suma calificaciones)
	//
	//Dise�o
	//Leer Pt , St y Pr
	//Calcular S_c(P_T + S_T, + Pr)
	//Definir C_M (si el 100% esta compuesto por tres notas, si se sacara un 10 en todas el 10 valdr�a 30)
	//Calcular C_f = (S_c * 10) / C_M 
	//Mostrar C_f
	
	Definir Pt , St , Pr , CM , Sc , Cf Como Real;
	
	CM := 30;
	
	Escribir "Ingrese su calificaci�n del Primer Test";
	Leer Pt;
	Escribir "Ingrese su calificaci�n del Segundo Test";
	Leer St;
	Escribir "Ingrese su calificaci�n de las Pr�cticas";
	Leer Pr;
	
	Sc := Pt + St + Pr;
	
	Cf := (Sc * 10) / CM;
	
	Escribir "Su calificaci�n final es: " , Cf;
	
	
FinProceso
