<?php
    //PASO CERO: PREPARAR SENTENCIA 
    //Asignar a variables los datos de la conexión
    $servidor = 'localhost:3307'; 
    $usuario = 'root'; 
    $password = ''; 
    //para conectarnos vamos a utilizar mysqli_connect(Servidor, Usuario, Contraseña, BD)
    //abre/crea la conexión con el servidor/BD y si no se puede conectar finaliza la ejecución del programa mostrando un mensaje de error 
    //or die("Error (con die)");
    $conexion = mysqli_connect($servidor, $usuario, $password); 
    //echo "Conectado a mySql<br>"; 

    if(!$conexion){
        echo"Error de conexión: " . mysqli_connect_error(); 
    } else {
        echo "Conectado a MySql"; 
    }
?>